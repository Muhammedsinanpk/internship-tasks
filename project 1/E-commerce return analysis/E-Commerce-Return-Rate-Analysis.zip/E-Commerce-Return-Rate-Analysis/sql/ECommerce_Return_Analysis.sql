USE ecommerce_return_analysis;
SELECT DATABASE();
SELECT COUNT(*) AS total_rows
FROM cleaned_ecommerce_data;
DESCRIBE cleaned_ecommerce_data;
SELECT
    COUNT(*) AS total_orders,
    SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) AS returned_orders,
    SUM(CASE WHEN returned = 'No' THEN 1 ELSE 0 END) AS non_returned_orders,
    ROUND(
        SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) * 100.0
        / COUNT(*),
        2
    ) AS return_rate_percent
FROM cleaned_ecommerce_data;
SELECT
    category,
    COUNT(*) AS total_orders,
    SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) AS returned_orders,
    ROUND(
        SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) * 100.0
        / COUNT(*),
        2
    ) AS return_rate_percent
FROM cleaned_ecommerce_data
GROUP BY category
ORDER BY return_rate_percent DESC;
SELECT
    region,
    COUNT(*) AS total_orders,
    SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) AS returned_orders,
    ROUND(
        SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) * 100.0
        / COUNT(*),
        2
    ) AS return_rate_percent
FROM cleaned_ecommerce_data
GROUP BY region
ORDER BY return_rate_percent DESC;
SELECT
    payment_method,
    COUNT(*) AS total_orders,
    SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) AS returned_orders,
    ROUND(
        SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) * 100.0
        / COUNT(*),
        2
    ) AS return_rate_percent
FROM cleaned_ecommerce_data
GROUP BY payment_method
ORDER BY return_rate_percent DESC;
SELECT
    return_reason,
    COUNT(*) AS returned_orders,
    ROUND(
        COUNT(*) * 100.0 /
        (SELECT COUNT(*)
         FROM cleaned_ecommerce_data
         WHERE returned = 'Yes'),
        2
    ) AS percentage_of_returns
FROM cleaned_ecommerce_data
WHERE returned = 'Yes'
GROUP BY return_reason
ORDER BY returned_orders DESC;
SELECT
    category,
    return_reason,
    COUNT(*) AS returned_orders
FROM cleaned_ecommerce_data
WHERE returned = 'Yes'
GROUP BY category, return_reason
ORDER BY category, returned_orders DESC;
WITH category_reasons AS (
    SELECT
        category,
        return_reason,
        COUNT(*) AS returned_orders
    FROM cleaned_ecommerce_data
    WHERE returned = 'Yes'
    GROUP BY category, return_reason
),
ranked_reasons AS (
    SELECT
        category,
        return_reason,
        returned_orders,
        ROW_NUMBER() OVER (
            PARTITION BY category
            ORDER BY returned_orders DESC
        ) AS reason_rank
    FROM category_reasons
)
SELECT
    category,
    return_reason,
    returned_orders
FROM ranked_reasons
WHERE reason_rank = 1
ORDER BY category;SELECT
    order_year,
    order_month,
    order_month_name,
    COUNT(*) AS total_orders,
    SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) AS returned_orders,
    ROUND(
        SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) * 100.0
        / COUNT(*),
        2
    ) AS return_rate_percent
FROM cleaned_ecommerce_data
GROUP BY
    order_year,
    order_month,
    order_month_name
ORDER BY
    order_year,
    order_month;
    SELECT
    returned,
    COUNT(*) AS total_orders,
    ROUND(AVG(price), 2) AS average_price,
    ROUND(AVG(shipping_cost), 2) AS average_shipping_cost,
    ROUND(AVG(profit_margin), 2) AS average_profit_margin,
    ROUND(AVG(total_amount), 2) AS average_order_value
FROM cleaned_ecommerce_data
GROUP BY returned
ORDER BY returned DESC;
SELECT
    order_id,
    customer_id,
    category,
    price,
    quantity,
    total_amount,
    shipping_cost,
    profit_margin,
    return_reason
FROM cleaned_ecommerce_data
WHERE returned = 'Yes'
ORDER BY total_amount DESC
LIMIT 10;
SELECT
    customer_id,
    COUNT(*) AS total_orders,
    SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) AS returned_orders,
    ROUND(
        SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) * 100.0
        / COUNT(*),
        2
    ) AS return_rate_percent,
    ROUND(SUM(total_amount), 2) AS total_spending
FROM cleaned_ecommerce_data
GROUP BY customer_id
HAVING COUNT(*) >= 3
ORDER BY return_rate_percent DESC, total_orders DESC
LIMIT 20;
SELECT
    customer_id,
    COUNT(*) AS total_orders,
    SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) AS returned_orders,
    ROUND(
        SUM(total_amount), 2
    ) AS total_spending
FROM cleaned_ecommerce_data
GROUP BY customer_id
HAVING COUNT(*) >= 3
ORDER BY returned_orders DESC
LIMIT 20;
SELECT
    returned,
    COUNT(*) AS total_orders,
    ROUND(AVG(delivery_days), 2) AS average_delivery_days,
    MIN(delivery_days) AS minimum_delivery_days,
    MAX(delivery_days) AS maximum_delivery_days
FROM cleaned_ecommerce_data
GROUP BY returned
ORDER BY returned DESC;
SELECT
    delivery_days,
    COUNT(*) AS total_orders,
    SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) AS returned_orders,
    ROUND(
        SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) * 100.0
        / COUNT(*),
        2
    ) AS return_rate_percent
FROM cleaned_ecommerce_data
GROUP BY delivery_days
ORDER BY delivery_days;
SELECT
    discount,
    COUNT(*) AS total_orders,
    SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) AS returned_orders,
    ROUND(
        SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) * 100.0
        / COUNT(*),
        2
    ) AS return_rate_percent
FROM cleaned_ecommerce_data
GROUP BY discount
ORDER BY discount;
SELECT
    quantity,
    COUNT(*) AS total_orders,
    SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) AS returned_orders,
    ROUND(
        SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) * 100.0
        / COUNT(*),
        2
    ) AS return_rate_percent
FROM cleaned_ecommerce_data
GROUP BY quantity
ORDER BY quantity;
SELECT
    returned,
    COUNT(*) AS total_orders,
    ROUND(AVG(discount), 4) AS average_discount,
    ROUND(AVG(quantity), 2) AS average_quantity
FROM cleaned_ecommerce_data
GROUP BY returned
ORDER BY returned DESC;
SELECT
    category,
    COUNT(*) AS total_orders,
    SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) AS returned_orders,
    ROUND(SUM(total_amount), 2) AS total_sales,
    ROUND(
        SUM(CASE WHEN returned = 'Yes' THEN total_amount ELSE 0 END),
        2
    ) AS returned_sales_value,
    ROUND(
        SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) * 100.0
        / COUNT(*),
        2
    ) AS return_rate_percent
FROM cleaned_ecommerce_data
GROUP BY category
ORDER BY returned_sales_value DESC;
SELECT
    region,
    COUNT(*) AS total_orders,
    SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) AS returned_orders,
    ROUND(SUM(total_amount), 2) AS total_sales,
    ROUND(
        SUM(CASE WHEN returned = 'Yes' THEN total_amount ELSE 0 END),
        2
    ) AS returned_sales_value,
    ROUND(
        SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) * 100.0
        / COUNT(*),
        2
    ) AS return_rate_percent
FROM cleaned_ecommerce_data
GROUP BY region
ORDER BY returned_sales_value DESC;
SELECT
    return_reason,
    COUNT(*) AS returned_orders,
    ROUND(SUM(total_amount), 2) AS returned_sales_value,
    ROUND(AVG(total_amount), 2) AS average_order_value
FROM cleaned_ecommerce_data
WHERE returned = 'Yes'
GROUP BY return_reason
ORDER BY returned_sales_value DESC;
SELECT
    COUNT(*) AS total_orders,
    SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) AS returned_orders,
    ROUND(SUM(total_amount), 2) AS total_sales,
    ROUND(
        SUM(CASE WHEN returned = 'Yes' THEN total_amount ELSE 0 END),
        2
    ) AS returned_sales_value,
    ROUND(
        SUM(CASE WHEN returned = 'Yes' THEN total_amount ELSE 0 END)
        * 100.0 / SUM(total_amount),
        2
    ) AS returned_sales_percentage
FROM cleaned_ecommerce_data;
WITH category_returns AS (
    SELECT
        category,
        COUNT(*) AS total_orders,
        SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) AS returned_orders,
        ROUND(
            SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END)
            * 100.0 / COUNT(*),
            2
        ) AS return_rate_percent
    FROM cleaned_ecommerce_data
    GROUP BY category
)
SELECT *
FROM category_returns
ORDER BY return_rate_percent DESC
LIMIT 1;
WITH region_returns AS (
    SELECT
        region,
        COUNT(*) AS total_orders,
        SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) AS returned_orders,
        ROUND(
            SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END)
            * 100.0 / COUNT(*),
            2
        ) AS return_rate_percent
    FROM cleaned_ecommerce_data
    GROUP BY region
)
SELECT *
FROM region_returns
ORDER BY return_rate_percent DESC
LIMIT 1;
SELECT
    return_reason,
    COUNT(*) AS returned_orders,
    ROUND(
        COUNT(*) * 100.0 /
        (
            SELECT COUNT(*)
            FROM cleaned_ecommerce_data
            WHERE returned = 'Yes'
        ),
        2
    ) AS percentage_of_returns
FROM cleaned_ecommerce_data
WHERE returned = 'Yes'
GROUP BY return_reason
ORDER BY returned_orders DESC
LIMIT 1;
WITH monthly_returns AS (
    SELECT
        order_year,
        order_month,
        order_month_name,
        COUNT(*) AS total_orders,
        SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) AS returned_orders,
        ROUND(
            SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END)
            * 100.0 / COUNT(*),
            2
        ) AS return_rate_percent
    FROM cleaned_ecommerce_data
    GROUP BY
        order_year,
        order_month,
        order_month_name
)
SELECT *
FROM monthly_returns
ORDER BY return_rate_percent DESC
LIMIT 1;
/*
========================================================
PHASE 5 — SQL ANALYSIS CONCLUSION
========================================================

Key Business Findings:

1. The overall return rate is approximately 5.52%.

2. Fashion has the highest return rate among the major
   product categories, while Grocery has the lowest.

3. "Not as described" is the most common return reason.

4. Return reasons differ by product category. Fashion and
   Toys are strongly associated with "Not as described",
   while Home is associated with "Missing/Wrong item".

5. The East region has the highest regional return rate,
   while Central has the lowest.

6. PayPal has the highest return rate among the analyzed
   payment methods, while COD has the lowest.

7. Returned orders have a higher average product price
   than non-returned orders.

8. Discount, quantity, customer age and delivery time show
   relatively small differences between returned and
   non-returned orders.

9. Monthly return rates vary over time, with September 2024
   recording the highest observed monthly return rate.

Business Recommendation:

The company should focus on category-specific return
reduction strategies, particularly improving product
descriptions and product information for categories where
"Not as described" is a major return reason. Operational
checks should also be strengthened for categories affected
by missing or incorrect items.

========================================================
END OF PHASE 5
========================================================
*/